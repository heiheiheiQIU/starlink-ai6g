import argparse
import os
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'source'))
from backend.api.main import app
from fastapi.staticfiles import StaticFiles
app.mount('/', StaticFiles(directory=ROOT/'frontend_dist', html=True), name='frontend')
if __name__ == '__main__':
    import uvicorn
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=8000)
    args = parser.parse_args()
    os.chdir(ROOT/'source')
    uvicorn.run(app, host='127.0.0.1', port=args.port)
